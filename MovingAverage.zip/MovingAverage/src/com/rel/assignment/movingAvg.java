package com.rel.assignment;

import java.util.Comparator;

public class movingAvg 
{
String customer;
int date;
double amountspet;
double movingavg;
public String getCustomer() {
	return customer;
}
public int getDate() {
	return date;
}
public double getAmountspet() {
	return amountspet;
}
public double getmovingavg() {
	return movingavg;
}

public void setMovingavg(double movingavg) {
	this.movingavg = movingavg;
}

public movingAvg(String customer, int date, double amountspet) {
	this.customer = customer;
	this.date = date;
	this.amountspet = amountspet;
}

public static Comparator<movingAvg> mov_CusdateComparator = new Comparator<movingAvg>() {

	public int compare(movingAvg s1, movingAvg s2) {
	   String Name1 = s1.getCustomer();
	   String Name2 = s2.getCustomer();
	   int date1 = s1.getDate();
	   int date2 = s2.getDate();
	   String Name1date1 = Name1+date1;
	   String Name2date2 = Name2+date2;
	   return Name1date1.compareTo(Name2date2);

    }


};
}
