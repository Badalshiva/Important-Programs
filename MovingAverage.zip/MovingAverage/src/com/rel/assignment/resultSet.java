package com.rel.assignment;

public class resultSet 
{
	String customer;
	int date;
	double amountspet;
	double movingavg;
	public String getCustomer() {
		return customer;
	}
	public int getDate() {
		return date;
	}
	public double getAmountspet() {
		return amountspet;
	}
	public double getmovingavg() {
		return movingavg;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public void getmovingavg(double movingavg) {
		this.movingavg = movingavg;
	}
	public void setDate(int date) {
		this.date = date;
	}
	public void setAmountspet(double amountspet) {
		this.amountspet = amountspet;
	}
	
}
