package com.rel.process;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rel.assignment.movingAvg;

public class calcMovingAvg 
{
	private static final String FILENAME = "C:/Users/rle0447/Desktop/IMP/Java/Assignment_1/TestFile - Copy.csv";
	private static final String FILENAME_1 = "C:/Users/rle0447/Desktop/IMP/Java/Assignment_1/output.txt";
	private static final ArrayList <movingAvg> mov_list= new ArrayList<>();
	
	public static void main(String[] args) throws IOException 
	{
		BufferedWriter bw = null;
		FileWriter fw = null;
		fw = new FileWriter(FILENAME_1);
		bw = new BufferedWriter(fw);
		System.out.println("Start of the first programme");
		BufferedReader br = new BufferedReader(new FileReader(FILENAME));
		
		try 
		{
			String line;
			line = br.readLine();
			while ((line = br.readLine()) != null) 
			{
				
				movingAvg obj_mov = CreatemovingAvgObject(line);
				if(!obj_mov.getCustomer().equals(" "))
				mov_list.add(obj_mov);
			}
			
			Collections.sort(mov_list, movingAvg.mov_CusdateComparator);
			
			 calculateAvg();
			 
			 for (int i = 0; i< mov_list.size(); i++)
				{
				    bw.write(mov_list.get(i).getCustomer() + "|");
					bw.write(mov_list.get(i).getDate() + "|");
					bw.write(Double.toString(mov_list.get(i).getAmountspet()) + "|");
					bw.write(Double.toString(mov_list.get(i).getmovingavg()));
					bw.newLine();
				}
			
		}
		catch (IOException e) 
		{
			System.out.println("Error found in java programme "+e.getMessage());
		} 
		catch(Exception e)
		{
			System.out.println("Error found in java programme "+e.toString());
		}
		
		finally 
		{
			if (br != null || fw != null || bw != null) 
			{
				br.close();
				bw.close();
				fw.close();
			}
	    }
	}

private static void calculateAvg() 
    {
	  for (int i = 0; i< mov_list.size(); i++)
	  {
		boolean prev = findPrev(mov_list.get(i).getCustomer(),mov_list.get(i).getDate(), i);
		System.out.println (prev+" "+mov_list.get(i).getCustomer()+mov_list.get(i).getDate());
		boolean next = findNext(mov_list.get(i).getCustomer(),mov_list.get(i).getDate(), i);
		//System.out.println (prev+" "+next+mov_list.get(i).getCustomer()+mov_list.get(i-1).getCustomer());
		if (prev == true && next == true)
		{
			double totalscore = (mov_list.get(i).getAmountspet() + mov_list.get(i-1).getAmountspet() 
					+ mov_list.get(i+1).getAmountspet()) / 3;
			mov_list.get(i).setMovingavg(totalscore);
	
		}else if( prev == false && next == true)
		{ 
	
			double totalscore = (mov_list.get(i).getAmountspet()+ mov_list.get(i+1).getAmountspet()) / 2;
			mov_list.get(i).setMovingavg(totalscore); 
		}  else if( prev == true && next == false)
		{  
			
				double totalscore = (mov_list.get(i).getAmountspet()+ mov_list.get(i-1).getAmountspet()) / 2	;
				mov_list.get(i).setMovingavg(totalscore);
		
		}  else if( prev == false && next == false)
		{  
			double totalscore = mov_list.get(i).getAmountspet();
			mov_list.get(i).setMovingavg(totalscore);  
		}  
		
	  }
		
	}



	private static boolean findNext(String customer, int date, int i) 
	{
		try
		{
			if(i == mov_list.size()-1)
				return false;
			System.out.println(mov_list.get(i+1).getCustomer());
			System.out.println(customer);
			System.out.println(mov_list.get(i+1).getDate()-1);
			System.out.println(date);
		if(customer.equals(mov_list.get(i+1).getCustomer())
				&& date == mov_list.get(i+1).getDate()-1){
			System.out.println(mov_list.get(i+1).getCustomer());
			System.out.println(customer);
			System.out.println(mov_list.get(i+1).getDate()-1);
			System.out.println(date);
			System.out.println(mov_list.get(i).getAmountspet());
			System.out.println(mov_list.get(i+1).getAmountspet());
			return true;
			
			
		}
		else	{
			System.out.println(mov_list.get(i+1).getCustomer());
			System.out.println(customer);
			System.out.println(mov_list.get(i+1).getDate());
			System.out.println(date);
		return false;
		}
		}
		catch (Exception e)
		{
			return false;
		}
	}


	private static boolean findPrev(String customer, int date, int i) 
	{
		int date1=0;
		System.out.println("Start of findPrev");
		System.out.println("i "+ i);
		try
		{
			if(i==0)
			{
				return false;
			}
		if(customer.equals(mov_list.get(i-1).getCustomer())
				&& date == (mov_list.get(i-1).getDate())+1)
		{
			 date1 = (mov_list.get(i-1).getDate())+1;
		System.out.println(date);
		System.out.println (date1);
			return true;
		}
			
		else	{
			System.out.println(date);
			System.out.println (date1);
		return false;
		}
		}
		catch (Exception e)
		{
			return false;
		}
}

	private static movingAvg CreatemovingAvgObject(String line) {
		String customer = " ";
		int date = 0;
		double amountspet = 0;
		
		String avg[] = line.split("\\|");
		System.out.println(line + "before object");
		if (avg.length == 3 && avg[0].length() > 0 && Double.parseDouble(avg[1]) > 0 ) 
		{
			customer = avg[0];
			System.out.println(avg[0].length());
			date = Integer.parseInt(avg[1]);
			Pattern pattern = Pattern.compile("\\s");
			Matcher matcher = pattern.matcher(avg[2]);
			boolean found = matcher.find();
			if(Pattern.matches("[a-zA-Z]+",avg[2]) == false && found == false)
			amountspet = Double.parseDouble(avg[2]);
			else
			amountspet = 0;
			
		}	
		return new movingAvg(customer,date,amountspet);
	}
}
