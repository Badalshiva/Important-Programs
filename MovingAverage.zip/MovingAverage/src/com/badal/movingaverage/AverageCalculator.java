package com.badal.movingaverage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Set;
import java.util.StringTokenizer;

public class AverageCalculator {

	/*To check previous value*/
	public static boolean isPrevious(CustomerBean bean, int i, ArrayList<CustomerBean> cList){
		
		if(i == 0)
			return false;
		else if(bean.getCustomer().equals(cList.get(i-1).getCustomer()))
			return true;
		
		return false;
	}
	
	/*To check Next Value*/
	public static boolean isNext(CustomerBean bean, int i, ArrayList<CustomerBean> cList){
	
		if(i == cList.size()-1)
			return false;
		else if(bean.getCustomer().equals(cList.get(i+1).getCustomer()))
			return true;
		
		return false;
	}
	
	/*Master method to processData and store it in an ArrayList*/
	public static void processData(ArrayList<String> array){
		
		ArrayList<CustomerBean> cList = new ArrayList<>();

		for(int i=0; i<array.size(); i++){

			/*Splitting the strings into different tokens to get the Customer, date and amountspent*/
			StringTokenizer st = new StringTokenizer(array.get(i), "|");

			/*to create a customer object which will hold the corresponding data*/
			CustomerBean c = new CustomerBean();
			while(st.hasMoreElements()){
				c.setCustomer(st.nextToken());
				c.setCdate(Integer.parseInt(st.nextToken()));
				String str = st.nextToken();
				
				Pattern p = Pattern.compile("\\s");
				Matcher m = p.matcher(str);
				boolean b = m.find();
				if(Pattern.matches("[a-zA-Z]+",str) == false && b == false && str.isEmpty() == false)
					c.setAmountspent(Double.parseDouble(str));
				else
					c.setAmountspent(0);
			}
			
			/*Adding to the arrayList which is of CustomerBean type */
			cList.add(c);
		}

		/*To sort the arrayList based on name and date */
		Collections.sort(cList, new DateComparator());
				
		/*Evaluating the moving average*/
		for(int i=0; i<cList.size();i++){
			
			CustomerBean c = cList.get(i);
			
			/*Condition to check whether both the prev and next value is available or not and also to get Prev+Current+Next*/
			if(isPrevious(c, i, cList) == true && isNext(c, i, cList) == true){
				double average = (cList.get(i-1).getAmountspent()+c.getAmountspent()+cList.get(i+1).getAmountspent())/3;
				System.out.println(c.getCustomer()+" ---- "+c.getCdate()+" ---- "+c.getAmountspent()+" ---- "+average);
			}
			/*Condition to check next value and moving average for Current+Next*/
			else if(isPrevious(c, i, cList) == false && isNext(c, i, cList) == true){
				double average = (c.getAmountspent()+cList.get(i+1).getAmountspent())/2;
				System.out.println(c.getCustomer()+" ---- "+c.getCdate()+" ---- "+c.getAmountspent()+" ---- "+average);
			}
			/*Condition to check prev value and moving */
			else{
				double average = (cList.get(i-1).getAmountspent()+c.getAmountspent())/2;
				System.out.println(c.getCustomer()+" ---- "+c.getCdate()+" ---- "+c.getAmountspent()+" ---- "+average);
			}
			
		}
			
	}

	public static void main(String[] args) {

		String csvFile = "res/TestFile.csv";

		ArrayList<String> array = new ArrayList<>();
		
		try{
			FileReader fileReader = new FileReader(csvFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuffer.append(line);
				array.add(line);

				stringBuffer.append("\n");
			}
			fileReader.close();
			
			/*Removing the Header*/
			//System.out.println(array.size());
			array.remove(0);
			
			//System.out.println(array.size());
			
			processData(array);


		}catch(IOException e){
			e.printStackTrace();
		}

	}

}
